
#ifndef  ATTINY25_H 
#define ATTINY25_H

#define  ON_OFF_50_50_OUTPUT (1 << PB3) 

#endif
